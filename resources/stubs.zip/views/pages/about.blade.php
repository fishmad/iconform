

@extends('layouts.master')
@section('content')


      <div class="container-fluid">
        <div class="animate fadeIn">
          <div class="card non-stock ">
            <div class="card-header non-stock">About</div>
            <div class="card-body">About Page

<h1>Lorem Ipsum</h1>
<h4>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."</h4>
<h5>"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</h5>

<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas feugiat, nulla at porttitor varius, ex orci ultrices arcu, ac finibus sapien eros quis arcu. Fusce et vestibulum justo. Integer nisi nulla, iaculis sed lorem consequat, ullamcorper condimentum nisi. Proin scelerisque vehicula efficitur. In nec varius dolor, eu feugiat dui. Vivamus consectetur justo diam. Praesent ultrices dapibus neque, ac facilisis nunc. Fusce blandit lorem et sapien dapibus placerat.
</p>
<p>
Integer massa nisl, feugiat at rhoncus eget, sollicitudin sit amet tortor. Mauris in sollicitudin est. Vestibulum ultricies pretium mollis. Phasellus fringilla mauris nec quam fringilla, vitae lobortis neque posuere. Cras porttitor condimentum nunc suscipit faucibus. Vivamus ut venenatis arcu. Donec finibus velit non blandit blandit.
</p>
<p>
Phasellus in bibendum leo. Maecenas varius molestie augue, eu consectetur est tempus id. Quisque ex urna, scelerisque in rhoncus vel, pulvinar vel massa. Integer ut bibendum erat. Sed accumsan ac lorem imperdiet cursus. Cras hendrerit varius erat, sit amet varius ex. Morbi blandit ante sed dui accumsan, sit amet accumsan eros maximus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis ullamcorper leo mauris. Nunc tortor turpis, lobortis ut eleifend et, auctor nec ex. Etiam tincidunt a eros et ultrices. Vivamus aliquet aliquet lorem id tempor. Duis sagittis, dui at auctor maximus, dui ex tristique augue, eget hendrerit mauris nisl dapibus mi. Cras ut facilisis sem, at egestas nisi. In quis nisl non erat scelerisque laoreet id eget sapien. Phasellus nec rhoncus massa.
</p>
<p>
Pellentesque id posuere lacus. Vivamus at lacus id nulla ultrices condimentum at a lectus. Phasellus pretium placerat quam, vel faucibus ipsum placerat sed. Praesent pellentesque bibendum malesuada. Mauris leo purus, iaculis egestas mollis nec, convallis quis arcu. In egestas quam non leo volutpat ultrices. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus libero est, sollicitudin sed dui eget, malesuada fermentum nunc. Nunc rutrum lectus libero, non venenatis lectus consectetur sed. Praesent tincidunt mi in massa aliquam, faucibus sagittis velit scelerisque.
</p>
<p>
Phasellus gravida pellentesque ligula. Pellentesque vel sem faucibus nulla mattis semper. Curabitur ornare porta tristique. Aliquam scelerisque ligula eget augue vehicula, vitae aliquam enim sollicitudin. Nullam nec molestie leo. Quisque urna nibh, accumsan id libero vel, vulputate laoreet augue. Praesent at dolor vestibulum ante convallis tempor. Nulla facilisi. Nunc nisi lectus, vestibulum ut felis nec, efficitur vulputate dolor. Vestibulum condimentum feugiat turpis a gravida. Mauris hendrerit convallis ante, ac pellentesque massa imperdiet quis. Phasellus lobortis ipsum sit amet ipsum viverra, sed rhoncus felis eleifend. Ut id auctor ante. Ut nec purus id ligula suscipit rutrum in non erat. Pellentesque sagittis eros in efficitur feugiat. In maximus mattis est sed pellentesque.
</p>
<p>
Integer massa nisl, feugiat at rhoncus eget, sollicitudin sit amet tortor. Mauris in sollicitudin est. Vestibulum ultricies pretium mollis. Phasellus fringilla mauris nec quam fringilla, vitae lobortis neque posuere. Cras porttitor condimentum nunc suscipit faucibus. Vivamus ut venenatis arcu. Donec finibus velit non blandit blandit.
</p>
<p>
Phasellus in bibendum leo. Maecenas varius molestie augue, eu consectetur est tempus id. Quisque ex urna, scelerisque in rhoncus vel, pulvinar vel massa. Integer ut bibendum erat. Sed accumsan ac lorem imperdiet cursus. Cras hendrerit varius erat, sit amet varius ex. Morbi blandit ante sed dui accumsan, sit amet accumsan eros maximus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis ullamcorper leo mauris. Nunc tortor turpis, lobortis ut eleifend et, auctor nec ex. Etiam tincidunt a eros et ultrices. Vivamus aliquet aliquet lorem id tempor. Duis sagittis, dui at auctor maximus, dui ex tristique augue, eget hendrerit mauris nisl dapibus mi. Cras ut facilisis sem, at egestas nisi. In quis nisl non erat scelerisque laoreet id eget sapien. Phasellus nec rhoncus massa.
</p>
<p>
Pellentesque id posuere lacus. Vivamus at lacus id nulla ultrices condimentum at a lectus. Phasellus pretium placerat quam, vel faucibus ipsum placerat sed. Praesent pellentesque bibendum malesuada. Mauris leo purus, iaculis egestas mollis nec, convallis quis arcu. In egestas quam non leo volutpat ultrices. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus libero est, sollicitudin sed dui eget, malesuada fermentum nunc. Nunc rutrum lectus libero, non venenatis lectus consectetur sed. Praesent tincidunt mi in massa aliquam, faucibus sagittis velit scelerisque.
</p>
<p>
Phasellus gravida pellentesque ligula. Pellentesque vel sem faucibus nulla mattis semper. Curabitur ornare porta tristique. Aliquam scelerisque ligula eget augue vehicula, vitae aliquam enim sollicitudin. Nullam nec molestie leo. Quisque urna nibh, accumsan id libero vel, vulputate laoreet augue. Praesent at dolor vestibulum ante convallis tempor. Nulla facilisi. Nunc nisi lectus, vestibulum ut felis nec, efficitur vulputate dolor. Vestibulum condimentum feugiat turpis a gravida. Mauris hendrerit convallis ante, ac pellentesque massa imperdiet quis. Phasellus lobortis ipsum sit amet ipsum viverra, sed rhoncus felis eleifend. Ut id auctor ante. Ut nec purus id ligula suscipit rutrum in non erat. Pellentesque sagittis eros in efficitur feugiat. In maximus mattis est sed pellentesque.
</p>

              @if (session('status'))
              <div class="alert alert-success">
                {{ session('status') }}
              </div>
              @endif

            </div><!-- ./card-body-->
          </div><!-- ./card-->
        </div><!-- ./animate fadeIn-->
      </div><!-- ./container-fluid-->
@endsection
