    <!-- sidebar -->
    <div class="sidebar">
      <nav class="sidebar-nav">
        <ul class="nav">

          @include('layouts.partials.menu-auto-generated')

          @include('layouts.partials.menu-demo-coreui')

        </ul>
      </nav>
      <button class="sidebar-minimizer brand-minimizer" type="button"></button>
    </div><!-- /.sidebar -->
