
<!-- footer -->
  <footer class="app-footer">
    <span><a href="http://iconform.com.au">iConform</a> © {{ date("Y") }} Fishmad.</span>
    <span class="ml-auto">Powered by <a href="http://laravel.com">Laravel</a> &amp; <a href="http://coreui.io">CoreUI</a></span>
  </footer><!-- /footer -->
