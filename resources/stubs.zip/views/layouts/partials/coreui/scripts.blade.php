
  <!-- Bootstrap and necessary plugins -->
  <script src="{{ asset('js/vendor/jquery.min.js') }}"></script>
  <script src="{{ asset('js/vendor/popper.min.js') }}"></script>
  <script src="{{ asset('js/vendor/bootstrap.min.js') }}"></script>
  <script src="{{ asset('js/vendor/pace.min.js') }}"></script>
  <!-- Plugins and scripts required by all views -->
  <script src="{{ asset('js/vendor/Chart.min.js') }}"></script>
  <!-- CoreUI main scripts -->
  <script src="{{ asset('js/app.js') }}"></script>

  <!-- BODY options, add following classes to body to change options
  '.header-fixed' - Fixed Header
  '.brand-minimized' - Minimized brand (Only symbol)
  '.sidebar-fixed' - Fixed Sidebar
  '.sidebar-hidden' - Hidden Sidebar
  '.sidebar-off-canvas' - Off Canvas Sidebar
  '.sidebar-minimized'- Minimized Sidebar (Only icons)
  '.sidebar-compact'    - Compact Sidebar
  '.aside-menu-fixed' - Fixed Aside Menu
  '.aside-menu-hidden'- Hidden Aside Menu
  '.aside-menu-off-canvas' - Off Canvas Aside Menu
  '.breadcrumb-fixed'- Fixed Breadcrumb
  '.footer-fixed'- Fixed footer
  -->